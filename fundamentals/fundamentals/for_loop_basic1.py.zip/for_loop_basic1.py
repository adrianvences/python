# for i in range (151):
#     print (i)

# for i in range (5,1001,5):
#     print (i)

# for num in range (1,100):
#     string = ""
#     if num % 5 == 0 :
#         string = string + "coding"
#     if num % 10 == 0 :
#         string = string + "coding dojo"
#         print (string, end = " ")

# for num in range (100):
#     if num %5==0 :
#         print ("coding")
#     if num %10==0 : 
#         print ("coding dojo")
#     else:
#         print (num)

# sum = 0
# for num in range(0,500000):
#     if num % 2 == 0:
#         sum = sum + num
# print (sum)

# for num in range (2018,1,-4):
#     print(num)

# lowNum=2 
# highNum=9
# mult=3 

# for num in range (lowNum,highNum+1):
#     if num % mult == 0:
#         print(num)